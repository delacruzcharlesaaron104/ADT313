import { useCallback, useState } from 'react';
import data from './MOCK_DATA.json';

export default function Problem6() {
  const [cars, setCars] = useState(data);
  const [selected, setSelected] = useState(null);
  const [formData, setFormData] = useState({
    vin: '',
    make: '',
    model: '',
    year: '',
    color: '',
  });

  const handleEdit = useCallback((car) => {
    setSelected(car);
    setFormData({
      vin: car.vin,
      make: car.make,
      model: car.model,
      year: car.year,
      color: car.color,
    });
  }, []);

  const handleDelete = useCallback((vin) => {
    setCars((prevCars) => prevCars.filter((car) => car.vin !== vin));
  }, []);

  const handleSave = useCallback(() => {
    setCars((prevCars) => [...prevCars, formData]);
    setFormData({
      vin: '',
      make: '',
      model: '',
      year: '',
      color: '',
    });
  }, [formData]);

  const handleUpdate = useCallback(() => {
    setCars((prevCars) =>
      prevCars.map((car) =>
        car.vin === selected.vin ? { ...car, ...formData } : car
      )
    );
    setSelected(null);
    setFormData({
      vin: '',
      make: '',
      model: '',
      year: '',
      color: '',
    });
  }, [formData, selected]);

  const handleClear = useCallback(() => {
    setFormData({
      vin: '',
      make: '',
      model: '',
      year: '',
      color: '',
    });
    setSelected(null);
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          VIN:{' '}
          <input
            type="text"
            name="vin"
            value={formData.vin}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Make:{' '}
          <input
            type="text"
            name="make"
            value={formData.make}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Model:{' '}
          <input
            type="text"
            name="model"
            value={formData.model}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Year:{' '}
          <input
            type="text"
            name="year"
            value={formData.year}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Color:{' '}
          <input
            type="text"
            name="color"
            value={formData.color}
            onChange={handleInputChange}
          />
        </div>
        <button type="button" onClick={handleSave}>
          Save
        </button>
        <button type="button" onClick={handleClear}>
          Clear
        </button>
        {selected && (
          <button type="button" onClick={handleUpdate}>
            Update
          </button>
        )}
      </div>

      <div className="table-container">
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>VIN</th>
              <th>Make</th>
              <th>Model</th>
              <th>Year</th>
              <th>Color</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {cars.map((car, index) => {
              return (
                <tr key={index}>
                  <td>{car.vin}</td>
                  <td>{car.make}</td>
                  <td>{car.model}</td>
                  <td>{car.year}</td>
                  <td>{car.color}</td>
                  <td>
                    <button type="button" onClick={() => handleEdit(car)}>
                      Edit
                    </button>
                    <button type="button" onClick={() => handleDelete(car.vin)}>
                      Delete
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}
