import { useReducer, useState } from 'react';
import data from './problem8mock_data.json';

const CREATE = 'CREATE';
const UPDATE = 'UPDATE';
const DELETE = 'DELETE';
const CLEAR = 'CLEAR';
const SELECT = 'SELECT';

const initialState = {
  foods: data,
  selectedFood: null,
};

function foodReducer(state, action) {
  switch (action.type) {
    case CREATE:
      return {
        ...state,
        foods: [...state.foods, action.payload],
      };
    case UPDATE:
      return {
        ...state,
        foods: state.foods.map((food, index) =>
          index === action.payload.index ? action.payload.food : food
        ),
      };
    case DELETE:
      return {
        ...state,
        foods: state.foods.filter((food, index) => index !== action.payload),
      };
    case CLEAR:
      return {
        ...state,
        selectedFood: null,
      };
    case SELECT:
      return {
        ...state,
        selectedFood: action.payload,
      };
    default:
      return state;
  }
}

export default function Problem8() {
  const [state, dispatch] = useReducer(foodReducer, initialState);
  const [foodName, setFoodName] = useState('');
  const [price, setPrice] = useState('');
  const [expirationDate, setExpirationDate] = useState('');
  const [calories, setCalories] = useState('');

  const handleCreate = () => {
    const newFood = { food_name: foodName, price, expiration_date: expirationDate, calories };
    dispatch({ type: CREATE, payload: newFood });
    clearForm();
  };

  const handleEdit = () => {
    const updatedFood = { food_name: foodName, price, expiration_date: expirationDate, calories };
    dispatch({ type: UPDATE, payload: { index: state.selectedFood.index, food: updatedFood } });
    clearForm();
  };

  const handleDelete = () => {
    dispatch({ type: DELETE, payload: state.selectedFood.index });
    clearForm();
  };

  const handleSelect = (index) => {
    dispatch({ type: SELECT, payload: { ...state.foods[index], index } });
  };

  const clearForm = () => {
    setFoodName('');
    setPrice('');
    setExpirationDate('');
    setCalories('');
  };

  const handleClear = () => {
    clearForm();
    dispatch({ type: CLEAR });
  };

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          Food Name:{' '}
          <input
            type="text"
            value={foodName || (state.selectedFood ? state.selectedFood.food_name : '')}
            onChange={(e) => setFoodName(e.target.value)}
          />
        </div>
        <div style={{ display: 'block' }}>
          Price:{' '}
          <input
            type="text"
            value={price || (state.selectedFood ? state.selectedFood.price : '')}
            onChange={(e) => setPrice(e.target.value)}
          />
        </div>
        <div style={{ display: 'block' }}>
          Expiration Date:{' '}
          <input
            type="text"
            value={expirationDate || (state.selectedFood ? state.selectedFood.expiration_date : '')}
            onChange={(e) => setExpirationDate(e.target.value)}
          />
        </div>
        <div style={{ display: 'block' }}>
          Calories:{' '}
          <input
            type="text"
            value={calories || (state.selectedFood ? state.selectedFood.calories : '')}
            onChange={(e) => setCalories(e.target.value)}
          />
        </div>

        <button type="button" onClick={handleCreate}>
          Save
        </button>
        <button type="button" onClick={handleClear}>
          Clear
        </button>
        {state.selectedFood && (
          <button type="button" onClick={handleEdit}>
            Update
          </button>
        )}
        {state.selectedFood && (
          <button type="button" onClick={handleDelete}>
            Delete
          </button>
        )}
      </div>

      <div className="table-container">
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>Food Name</th>
              <th>Price</th>
              <th>Expiration Date</th>
              <th>Calories</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {state.foods.map((food, index) => (
              <tr
                key={index}
                onClick={() => handleSelect(index)}
                style={{ cursor: 'pointer' }}
              >
                <td>{food.food_name}</td>
                <td>{food.price}</td>
                <td>{food.expiration_date}</td>
                <td>{food.calories}</td>
                <td>
                  <button type="button" onClick={() => handleSelect(index)}>
                    Edit
                  </button>
                  <button type="button" onClick={() => dispatch({ type: DELETE, payload: index })}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
