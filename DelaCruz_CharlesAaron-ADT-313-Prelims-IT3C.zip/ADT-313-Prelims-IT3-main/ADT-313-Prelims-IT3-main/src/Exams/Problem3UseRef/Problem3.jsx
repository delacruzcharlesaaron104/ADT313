import React, { useRef } from 'react';

function Problem3() {
  const inputRefs = useRef(Array.from({ length: 10 }, () => React.createRef()));

  const handleFocusEmptyInput = () => {
    for (let i = 0; i < inputRefs.current.length; i++) {
      if (inputRefs.current[i].current && inputRefs.current[i].current.value === '') {
        inputRefs.current[i].current.focus();
        break;
      }
    }
  };

  return (
    <>
      {inputRefs.current.map((inputRef, index) => (
        <div key={index} style={{ display: 'block' }}>
          Input {index + 1}: <input ref={inputRef} type="text" />
        </div>
      ))}
      <button type="button" onClick={handleFocusEmptyInput}>
        Focus on Empty Input
      </button>
    </>
  );
}

export default Problem3;
