import { useEffect, useRef, useState } from 'react';
import Loading from './Problem5Components/Loading';

export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true);
  const [isTyping, setIsTyping] = useState(false);
  const idleTimeoutRef = useRef(null);

  // Dismiss loading component after 3 seconds
  useEffect(() => {
    const loadingTimeout = setTimeout(() => {
      setIsLoading(false);
    }, 3000);
    return () => clearTimeout(loadingTimeout);
  }, []);


  const handleInputChange = () => {
    setIsTyping(true);
    if (idleTimeoutRef.current) clearTimeout(idleTimeoutRef.current);

  
    idleTimeoutRef.current = setTimeout(() => {
      setIsTyping(false);
    }, 2000);
  };

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <div style={{ display: 'block' }}>
          Input: <input type="text" onChange={handleInputChange} />
          <p>{isTyping ? 'User is typing...' : 'User is idle...'}</p>
        </div>
      )}
    </>
  );
}
