import React, { useContext } from 'react';
import { DataContext } from '../Problem7';

function Lists() {
  const { data, setSelectedData } = useContext(DataContext);
  const handleSelect = (row) => {
    setSelectedData(row);
  };

  return data.length ? (
    <table style={{ width: '100%' }}>
      <thead>
        <tr>
          <th>Title</th>
          <th>Genre</th>
          <th>Release Date</th>
          <th>Director</th>
          <th>Actor 1</th>
          <th>Actor 2</th>
          <th>Rating</th>
          <th>Box Office</th>
          <th>Duration (Minutes)</th>
          <th>Language</th>
        </tr>
      </thead>
      <tbody>
        {data.map((row, index) => (
          <tr
            key={index}
            style={{ cursor: 'pointer' }}
            onClick={() => handleSelect(row)}
          >
            <td>{row.title}</td>
            <td>{row.genre}</td>
            <td>{row.release_date}</td>
            <td>{row.director}</td>
            <td>{row.actor_1}</td>
            <td>{row.actor_2}</td>
            <td>{row.rating}</td>
            <td>{row.box_office}</td>
            <td>{row.duration_minutes}</td>
            <td>{row.language}</td>
          </tr>
        ))}
      </tbody>
    </table>
  ) : (
    <p>No movies available</p>
  );
}

export default Lists;
