import React, { createContext, useState } from 'react';
import SelectedValue from './Problem7Components/Selected';
import Lists from './Problem7Components/Lists';
import mockData from './problem7_mock_data.json';

export const DataContext = createContext();

export default function Problem7() {
  const [selectedData, setSelectedData] = useState(null);
  const [data, setData] = useState(mockData);

  return (
    <DataContext.Provider value={{ data, selectedData, setSelectedData }}>
      <div style={{ display: 'block' }}>
        <SelectedValue />
      </div>
      <div style={{ display: 'block' }}>
        <Lists />
      </div>
    </DataContext.Provider>
  );
}
